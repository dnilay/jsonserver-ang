# angular6-with-json-server

Simple Angular project

- Angular 6
- Angular CLI 1.5.0
- Json Server

Running the application
- npm install
- json-serve data.json (in the folder "/data")
- npm serve

or
- npm run dev



